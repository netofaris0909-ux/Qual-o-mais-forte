const animais = [
  // nome, força (quanto maior, mais forte), imagem
  {nome: "Leão", forca: 90, img: "https://images.unsplash.com/photo-1518717758536-85ae29035b6d?w=400"},
  {nome: "Gorila", forca: 97, img: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=400"},
  {nome: "Elefante", forca: 100, img: "https://images.unsplash.com/photo-1465101046530-73398c7f28ca?w=400"},
  {nome: "Urso", forca: 94, img: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=400"},
  {nome: "Tigre", forca: 91, img: "https://images.unsplash.com/photo-1518715308788-3d96e7f9a4c5?w=400"},
  {nome: "Hipopotamo", forca: 96, img: "https://images.unsplash.com/photo-1465101178521-c1a4c526c8d8?w=400"},
  {nome: "Crocodilo", forca: 93, img: "https://images.unsplash.com/photo-1470770841072-f978cf4d019e?w=400"},
  {nome: "Rinoceronte", forca: 95, img: "https://images.unsplash.com/photo-1518715308788-3d96e7f9a4c5?w=400"},
  {nome: "Cavalo", forca: 60, img: "https://images.unsplash.com/photo-1518715308788-3d96e7f9a4c5?w=400"},
  {nome: "Cachorro", forca: 30, img: "https://images.unsplash.com/photo-1518715308788-3d96e7f9a4c5?w=400"},
  {nome: "Gato", forca: 18, img: "https://images.unsplash.com/photo-1518715308788-3d96e7f9a4c5?w=400"},
  {nome: "Águia", forca: 40, img: "https://images.unsplash.com/photo-1518715308788-3d96e7f9a4c5?w=400"},
  {nome: "Lobo", forca: 55, img: "https://images.unsplash.com/photo-1518715308788-3d96e7f9a4c5?w=400"},
  {nome: "Tubarão", forca: 92, img: "https://images.unsplash.com/photo-1518715308788-3d96e7f9a4c5?w=400"},
  {nome: "Búfalo", forca: 87, img: "https://images.unsplash.com/photo-1518715308788-3d96e7f9a4c5?w=400"},
  {nome: "Canguru", forca: 49, img: "https://images.unsplash.com/photo-1518715308788-3d96e7f9a4c5?w=400"},
  {nome: "Orangotango", forca: 89, img: "https://images.unsplash.com/photo-1518715308788-3d96e7f9a4c5?w=400"},
  {nome: "Javali", forca: 70, img: "https://images.unsplash.com/photo-1518715308788-3d96e7f9a4c5?w=400"},
  {nome: "Camelo", forca: 65, img: "https://images.unsplash.com/photo-1518715308788-3d96e7f9a4c5?w=400"},
  {nome: "Cobra", forca: 59, img: "https://images.unsplash.com/photo-1518715308788-3d96e7f9a4c5?w=400"},
];

function animaisAleatorios() {
  let a = Math.floor(Math.random() * animais.length);
  let b;
  do {
    b = Math.floor(Math.random() * animais.length);
  } while (b === a);
  return [animais[a], animais[b]];
}

let rodada = animaisAleatorios();
let acertou = null;

function mostrarAnimais() {
  const animalsDiv = document.getElementById('animals');
  animalsDiv.innerHTML = '';
  rodada.forEach((animal, idx) => {
    const div = document.createElement('div');
    div.className = 'animal';
    div.innerHTML = `
      <img src="${animal.img}" alt="${animal.nome}">
      <div class="nome">${animal.nome}</div>
      <button class="escolher">Escolher</button>
    `;
    div.querySelector('.escolher').onclick = function() {
      if (acertou !== null) return;
      const outro = rodada[idx === 0 ? 1 : 0];
      if (animal.forca > outro.forca) {
        document.getElementById('resultado').textContent = 'Acertou, Guru! ' + animal.nome + ' é mais forte!';
        document.getElementById('resultado').style.color = '#5cff85';
      } else {
        document.getElementById('resultado').textContent = 'Tu perdeu, otário!';
        document.getElementById('resultado').style.color = '#ff5c5c';
      }
      acertou = true;
      document.getElementById('proxima').style.display = 'inline-block';
    };
    animalsDiv.appendChild(div);
  });
  document.getElementById('resultado').textContent = '';
  document.getElementById('proxima').style.display = 'none';
  acertou = null;
}

document.getElementById('proxima').onclick = function() {
  rodada = animaisAleatorios();
  mostrarAnimais();
};

// Inicial
mostrarAnimais();